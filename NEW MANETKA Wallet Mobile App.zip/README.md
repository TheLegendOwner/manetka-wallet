
  # NEW MANETKA Wallet Mobile App

  This is a code bundle for NEW MANETKA Wallet Mobile App. The original project is available at https://www.figma.com/design/aicRw1B4USpC5zuPKh5L7e/NEW-MANETKA-Wallet-Mobile-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  